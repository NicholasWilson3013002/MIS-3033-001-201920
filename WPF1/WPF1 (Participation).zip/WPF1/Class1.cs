﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF1
{
    class EntryForm
    {
        public string name { get; set; }
        
        public string address { get; set; }

        public int zip { get; set; }


    }
}
